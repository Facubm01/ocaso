package com.example.uade.tpo.TiendaRopa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaRopaApplicationTests {

	@Test
	void contextLoads() {
	}

}
