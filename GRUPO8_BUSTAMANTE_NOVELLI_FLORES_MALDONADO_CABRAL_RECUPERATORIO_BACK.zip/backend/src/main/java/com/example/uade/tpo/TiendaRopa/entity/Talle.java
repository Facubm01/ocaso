package com.example.uade.tpo.TiendaRopa.entity;

public enum Talle {
    XS, S, M, L, XL
}
