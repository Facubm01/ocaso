package com.example.uade.tpo.TiendaRopa.controllers.images;

import lombok.*;

@Data @AllArgsConstructor
public class ImageResponse {
  private Long id;
  private String file; // base64
}
