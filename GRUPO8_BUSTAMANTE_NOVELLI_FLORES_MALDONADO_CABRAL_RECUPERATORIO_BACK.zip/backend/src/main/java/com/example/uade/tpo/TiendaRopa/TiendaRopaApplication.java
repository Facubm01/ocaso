package com.example.uade.tpo.TiendaRopa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendaRopaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaRopaApplication.class, args);
	}

}
