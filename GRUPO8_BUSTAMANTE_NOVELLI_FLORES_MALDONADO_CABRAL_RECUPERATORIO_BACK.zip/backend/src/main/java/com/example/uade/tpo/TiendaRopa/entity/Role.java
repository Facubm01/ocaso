package com.example.uade.tpo.TiendaRopa.entity;

public enum Role {
    USER, ADMIN
}
